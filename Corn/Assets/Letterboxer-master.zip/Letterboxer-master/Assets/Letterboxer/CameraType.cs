﻿namespace Letterboxer
{
    public enum CameraType
    {
        MaintainAspectRatio = 0,
        BestPixelPerfectFit = 1
    }
}